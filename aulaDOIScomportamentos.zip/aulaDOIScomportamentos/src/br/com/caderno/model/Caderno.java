package br.com.caderno.model;

public class Caderno {
    public String cor;
    public String material;
    public double tamanho; // em cm (altura)

    public Caderno(String cor, String material, double tamanho) {
        this.cor = cor;
        this.material = material;
        this.tamanho = tamanho;
    }

    public void alterarCor(String novaCor) {
        //  a cor não pode ser vazia
        if (novaCor == null || novaCor.trim().isEmpty()) {
            System.out.println("Erro: A cor informada é inválida.");
            return;
        }
        this.cor = novaCor;
        System.out.println("Cor alterada. Nova cor: " + this.cor);
    }

    public void alterarMaterial(String novoMaterial) {
        // o material não pode ser vazio
        if (novoMaterial == null || novoMaterial.trim().isEmpty()) {
            System.out.println("Erro: O material informado é inválido.");
            return;
        }
        this.material = novoMaterial;
        System.out.println("Material alterado. Novo material: " + this.material);
    }

    public void alterarTamanho(double novoTamanho) {
        // Regra de negócio: o tamanho deve ser positivo
        if (novoTamanho <= 0) {
            System.out.println("Erro: O tamanho deve ser maior que zero.");
            return;
        }
        this.tamanho = novoTamanho;
        System.out.println("Tamanho alterado. Novo tamanho: " + this.tamanho + " cm");
    }

    public void exibirInfo() {
        System.out.println("Caderno -> Cor: " + cor + " | Material: " + material + " | Tamanho: " + tamanho + " cm");
    }
}